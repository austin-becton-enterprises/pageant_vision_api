from ..wrapper import DatabaseObjectWrapper
from ...constants.theater import forms
class FormObjectWrapper:

    data: DatabaseObjectWrapper

    def __init__(self, data: DatabaseObjectWrapper):
        self.data = data

    #def add_field()
    