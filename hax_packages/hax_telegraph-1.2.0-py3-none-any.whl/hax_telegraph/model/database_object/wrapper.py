#The core communication mechanism for all Hax libraries
import json
from ..constants import (foundation as foundation_constants, metatags as common_metatags)

class DatabaseObjectWrapper:

    data: dict = None

    def __init__(self, jsonDict: dict):
        if isinstance(jsonDict, dict) and jsonDict.get("data") is not None:
            self.data = jsonDict.get("data", {})
        else: self.data = jsonDict
#Main Funcs
    def tags(self) -> list:
        return self.data.get(foundation_constants.KEYNAME_TAGS)
    def prompt(self) -> str:
        return self.data.get(foundation_constants.KEYNAME_PROMPT)
    def value(self) -> str:
        return self.data.get(foundation_constants.KEYNAME_VALUE)
    def children(self) -> list:
        optional_children = self.data.get(foundation_constants.KEYNAME_CHILDREN)
        if optional_children is not None:
            formatted_children = list()
            for next_child in optional_children:
                formatted_children.append(DatabaseObjectWrapper(jsonDict=next_child))
            return formatted_children
        return None
    def update(self, new_tags: list = None, new_prompt: str = None, new_value: str = None, new_children: list = None):
        if new_tags is not None:
            self.data.update
    
#META TAGS AND RELATED
    def metaTags(self) -> dict:
        return self.data.get(foundation_constants.KEYNAME_METATAGS)
    def specificMetaTagValue(self, forKey: str) -> str:
        metaTags = self.metaTags()
        if metaTags is not None:
            return metaTags.get(forKey)
        return None
    def specificMetaTag(self, key: str, andValue: str) -> bool:
        value = self.specificMetaTagValue(forKey=key)
        if value is None: return False
        return value == andValue
    def clearMetaTags(self, should_keep_display_title: bool = True):
        display_title_tag: str = None
        if should_keep_display_title:
            display_title_tag = self.specificMetaTagValue(forKey=common_metatags.METATAG_KEYNAME_DISPLAYTITLE)
        self.data[foundation_constants.KEYNAME_METATAGS] = None
        if display_title_tag is not None:
            self.data[foundation_constants.KEYNAME_METATAGS] = dict()
            self.data[foundation_constants.KEYNAME_METATAGS][common_metatags.METATAG_KEYNAME_DISPLAYTITLE] = display_title_tag            
    def tags_match(self, tags_to_match_as_str: str) -> bool:
        this_object_tags = self.tags()
        if this_object_tags is not None:
            this_tags_as_str = ' '.join(this_object_tags)
            if this_tags_as_str == tags_to_match_as_str:
                return True
        return False
    def set_or_append(self, incoming_meta_tags: dict):
        metaTags = self.metaTags()
        if metaTags is not None:
            metaTags.update(incoming_meta_tags)
        else:
            self.data["metaTags"] = incoming_meta_tags
    def overwrite(self, 
                  incoming_meta_tags: dict = None, 
                  incoming_tags: list = None,
                  incoming_value: str = None,
                  incoming_prompt: prompt = None,
                  incoming_children: list = None,
                  should_keep_display_title_tag: bool = True):
        if incoming_meta_tags is not None:
            displayTitle: str = None
            if should_keep_display_title_tag:
                displayTitle = self.specificMetaTagValue(forKey=common_metatags.METATAG_KEYNAME_DISPLAYTITLE)
            self.data[foundation_constants.KEYNAME_METATAGS] = incoming_meta_tags
            if displayTitle is not None:
                self.metaTags()[common_metatags.METATAG_KEYNAME_DISPLAYTITLE] = displayTitle
        if incoming_tags is not None:
            self.data[foundation_constants.KEYNAME_TAGS] = incoming_tags
        if incoming_value is not None:
            self.data[foundation_constants.KEYNAME_VALUE] = incoming_value
        if incoming_prompt is not None:
            self.data[foundation_constants.KEYNAME_PROMPT] = incoming_prompt
        if incoming_children is not None:
            self.data[foundation_constants.KEYNAME_CHILDREN] = [child.data for child in incoming_children]

#JSON
    def toJSON(self) -> json:
        return json.dumps(self.data)
    
    def print(self):
        print(self.data)
