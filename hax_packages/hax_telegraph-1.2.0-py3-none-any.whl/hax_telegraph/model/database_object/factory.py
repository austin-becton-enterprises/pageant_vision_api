from ..constants.theater import foundation as theaterConstants
from wrapper import DatabaseObjectWrapper
from ..constants import (foundation as dbConstants, metatags as metatagKeys)

class Common:

    staticmethod 
    def simple_display_message(message: str) -> DatabaseObjectWrapper:
        return DatabaseObjectWrapper(jsonDict= {"value":message, 
                                                dbConstants.KEYNAME_METATAGS: {
                                                    metatagKeys.METATAG_KEYNAME_UITYPE:theaterConstants.METATAG_VALUES_UITYPE_DISPLAYTEXT }})

    staticmethod
    def basic_error_display_message() -> DatabaseObjectWrapper:
        return Common.simple_display_message(message="Sorry, there was an error getting your data.")




