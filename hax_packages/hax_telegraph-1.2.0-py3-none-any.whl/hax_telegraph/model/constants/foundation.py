#FOUNDATION - Core to the Database Object Wrapper Itself
KEYNAME_TAGS = 'tags'
KEYNAME_PROMPT = 'prompt'
KEYNAME_METATAGS = 'metaTags'
KEYNAME_VALUE = 'value'
KEYNAME_CHILDREN = 'children'

